/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;



int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    work_m_00000000004231734988_0206661081_init();
    work_m_00000000001061782081_0080689647_init();
    work_m_00000000000179601142_3080036049_init();
    work_m_00000000000592757164_2854645357_init();
    work_m_00000000000552140523_3230838343_init();
    work_m_00000000001071302222_3782814038_init();
    work_m_00000000004134447467_2073120511_init();


    xsi_register_tops("work_m_00000000001071302222_3782814038");
    xsi_register_tops("work_m_00000000004134447467_2073120511");


    return xsi_run_simulation(argc, argv);

}
